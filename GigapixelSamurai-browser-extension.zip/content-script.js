function imageName(value) {
  try {
    const path = new URL(value, location.href).pathname.split("/").pop();
    return decodeURIComponent(path || "image");
  } catch {
    return "image";
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.action !== "queue-image-from-page") return false;
  (async () => {
    try {
      // This request is made from the logged-in Mac page, so the site's own
      // cookies/session are available for private images.
      const source = await fetch(message.srcUrl, { credentials: "include" });
      if (!source.ok) throw new Error(`image request returned HTTP ${source.status}`);
      const blob = await source.blob();
      const filename = message.filename || imageName(message.srcUrl);
      const file = new File([blob], filename, { type: blob.type || "application/octet-stream" });
      const form = new FormData();
      form.append("files", file);
      form.append("project", message.project);
      form.append("model", message.model);
      form.append("scale", String(message.scale));
      form.append("strength", message.strength);
      form.append("labels", message.labels || "");
      const response = await fetch(`${String(message.endpoint).replace(/\/+$/, "")}/api/jobs`, {
        method: "POST",
        headers: { "Authorization": "Basic " + btoa(`${message.username}:${message.password}`) },
        body: form
      });
      const text = await response.text();
      if (!response.ok) throw new Error(text || `queue returned HTTP ${response.status}`);
      sendResponse({ ok: true });
    } catch (error) {
      sendResponse({ ok: false, error: String(error.message || error) });
    }
  })();
  return true;
});
