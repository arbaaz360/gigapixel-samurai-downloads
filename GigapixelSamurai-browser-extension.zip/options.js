const defaults = { endpoint: "https://gigapixel.novabyteworks.com", username: "", password: "", project: "Inbox", model: "wonder", scale: 4, strength: "high", labels: "" };
const ids = Object.keys(defaults);
const $ = (id) => document.getElementById(id);

(async () => {
  const values = { ...defaults, ...(await chrome.storage.local.get(defaults)) };
  for (const id of ids) $(id).value = values[id];
})();

$("save").onclick = async () => {
  const values = Object.fromEntries(ids.map((id) => [id, $(id).value]));
  values.scale = Number(values.scale);
  await chrome.storage.local.set(values);
  $("status").textContent = "Saved";
  setTimeout(() => $("status").textContent = "", 1800);
};
