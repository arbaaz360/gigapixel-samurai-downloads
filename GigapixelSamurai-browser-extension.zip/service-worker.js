const DEFAULTS = {
  endpoint: "https://gigapixel.novabyteworks.com",
  username: "",
  password: "",
  project: "Inbox",
  model: "wonder",
  scale: 4,
  strength: "high",
  labels: ""
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "send-to-gigapixel",
    title: "Send image to Gigapixel queue",
    contexts: ["image"]
  });
});

function notify(title, message) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: "icon.svg",
    title,
    message
  });
}

function filenameFromUrl(value) {
  try {
    const path = new URL(value).pathname.split("/").pop();
    return decodeURIComponent(path || "image");
  } catch {
    return "image";
  }
}

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== "send-to-gigapixel" || !info.srcUrl) return;
  const config = { ...DEFAULTS, ...(await chrome.storage.local.get(DEFAULTS)) };
  if (!config.username || !config.password) {
    await chrome.runtime.openOptionsPage();
    notify("Gigapixel Samurai", "Open the extension settings and save your queue login first.");
    return;
  }
  const endpoint = String(config.endpoint).replace(/\/+$/, "");
  const body = { srcUrl: info.srcUrl, filename: filenameFromUrl(info.srcUrl), endpoint, ...config, action: "queue-image-from-page" };
  try {
    let result;
    try {
      result = await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(info.tabId, body, { frameId: info.frameId || 0 }, (reply) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(reply);
        });
      });
    } catch {
      result = null;
    }
    if (!result) {
      // Fallback for pages where content scripts are unavailable. This works
      // for public images, while private images need the page-session path.
      const response = await fetch(`${endpoint}/api/jobs/url`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Basic " + btoa(`${config.username}:${config.password}`)
        },
        body: JSON.stringify({
          url: info.srcUrl,
          referer: info.pageUrl || "",
          filename: body.filename,
          project: config.project,
          model: config.model,
          scale: Number(config.scale),
          strength: config.strength,
          labels: config.labels
        })
      });
      const text = await response.text();
      if (!response.ok) throw new Error(text || `HTTP ${response.status}`);
    } else if (!result.ok) {
      throw new Error(result.error || "the logged-in page could not provide the image");
    }
    notify("Image queued", `${body.filename} was added to ${body.project}.`);
  } catch (error) {
    notify("Gigapixel queue failed", String(error.message || error));
  }
});
