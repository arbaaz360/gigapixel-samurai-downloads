# Browser right-click queue

This Chrome/Brave/Edge extension adds **Send image to Gigapixel queue** to the image context menu. It first fetches the image inside the current logged-in page, so images behind a Mac browser login can be queued. The Windows service receives the image bytes and applies the saved project, label, model, scale, and strength settings.

Install it on the Mac or any desktop browser with **Extensions → Developer mode → Load unpacked**, selecting this folder. Open the extension's **Options**, enter the queue address and the same Gigapixel Samurai username/password, then save.

If the page blocks content-script access, the extension falls back to asking the Windows service to fetch the URL; that fallback only works for public images. For a local file, use the Finder Quick Action.
