#!/bin/zsh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$HOME/Library/Application Support/GigapixelSamurai"
SERVICE_DIR="$HOME/Library/Services/Send to Gigapixel Queue.workflow"
mkdir -p "$APP_DIR" "$SERVICE_DIR/Contents/Resources"
cp "$ROOT/send_to_gigapixel.sh" "$APP_DIR/send_to_gigapixel.sh"
chmod 700 "$APP_DIR/send_to_gigapixel.sh"

cat > "$SERVICE_DIR/Contents/document.wflow" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>AMDocumentVersion</key><string>2</string>
  <key>actions</key>
  <array>
    <dict>
      <key>AMActionVersion</key><string>2.0.0</string>
      <key>ActionBundleIdentifier</key><string>com.apple.RunShellScript</string>
      <key>ActionParameters</key>
      <dict>
        <key>COMMAND_STRING</key><string>"$HOME/Library/Application Support/GigapixelSamurai/send_to_gigapixel.sh" "$@"</string>
        <key>CheckedForUserDefaultShell</key><true/>
        <key>inputMethod</key><integer>1</integer>
        <key>outputMethod</key><integer>0</integer>
        <key>shell</key><string>/bin/zsh</string>
      </dict>
      <key>CFBundleIdentifier</key><string>com.apple.RunShellScript</string>
    </dict>
  </array>
  <key>serviceApplicationBundleID</key><string>com.apple.finder</string>
  <key>serviceInputTypeIdentifier</key><string>public.item</string>
  <key>serviceOutputTypeIdentifier</key><string>public.item</string>
</dict>
</plist>
PLIST

/usr/bin/killall Finder >/dev/null 2>&1 || true
echo "Installed: Send to Gigapixel Queue"
echo "Right-click an image in Finder and choose Quick Actions → Send to Gigapixel Queue."
