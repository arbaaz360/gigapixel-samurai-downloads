#!/bin/zsh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$HOME/Library/Application Support/GigapixelSamurai"
SERVICE_DIR="$HOME/Library/Services/Send to Gigapixel Queue.workflow"

mkdir -p "$APP_DIR" "$HOME/Library/Services"
cp "$ROOT/send_to_gigapixel.sh" "$APP_DIR/send_to_gigapixel.sh"
chmod 700 "$APP_DIR/send_to_gigapixel.sh"

# Replace an older copy so Finder does not keep stale Automator metadata.
rm -rf "$SERVICE_DIR"
mkdir -p "$SERVICE_DIR/Contents"

cat > "$SERVICE_DIR/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>Send to Gigapixel Queue</string>
  <key>CFBundleIdentifier</key><string>com.gigapixelsamurai.finderqueue</string>
  <key>NSServices</key>
  <array>
    <dict>
      <key>NSMenuItem</key>
      <dict><key>default</key><string>Send to Gigapixel Queue</string></dict>
      <key>NSMessage</key><string>runWorkflowAsService</string>
      <key>NSSendFileTypes</key>
      <array>
        <string>public.png</string>
        <string>public.jpeg</string>
        <string>public.tiff</string>
        <string>public.heic</string>
        <string>com.compuserve.gif</string>
        <string>org.webmproject.webp</string>
      </array>
    </dict>
  </array>
</dict>
</plist>
PLIST

cat > "$SERVICE_DIR/Contents/document.wflow" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>AMApplicationBuild</key><string>523</string>
  <key>AMApplicationVersion</key><string>2.10</string>
  <key>AMDocumentVersion</key><string>2</string>
  <key>actions</key>
  <array>
    <dict>
      <key>action</key>
      <dict>
        <key>AMAccepts</key>
        <dict>
          <key>Container</key><string>List</string>
          <key>Optional</key><false/>
          <key>Types</key><array><string>com.apple.cocoa.path</string></array>
        </dict>
        <key>AMProvides</key>
        <dict>
          <key>Container</key><string>List</string>
          <key>Types</key><array><string>com.apple.cocoa.path</string></array>
        </dict>
        <key>ActionBundlePath</key><string>/System/Library/Automator/Run Shell Script.action</string>
        <key>ActionName</key><string>Run Shell Script</string>
        <key>ActionParameters</key>
        <dict>
          <key>COMMAND_STRING</key><string>"$HOME/Library/Application Support/GigapixelSamurai/send_to_gigapixel.sh" "$@"</string>
          <key>CheckedForUserDefaultShell</key><true/>
          <key>inputMethod</key><integer>1</integer>
          <key>shell</key><string>/bin/zsh</string>
          <key>source</key><string></string>
        </dict>
        <key>BundleIdentifier</key><string>com.apple.RunShellScript</string>
        <key>CFBundleVersion</key><string>2.0.3</string>
        <key>Class Name</key><string>RunShellScriptAction</string>
        <key>UUID</key><string>8D5A54E4-5B1D-47A9-81C8-3D831E5E73A6</string>
      </dict>
      <key>isViewVisible</key><false/>
    </dict>
  </array>
  <key>connectors</key><dict/>
  <key>workflowMetaData</key>
  <dict>
    <key>serviceApplicationBundleID</key><string>com.apple.finder</string>
    <key>serviceApplicationPath</key><string>/System/Library/CoreServices/Finder.app</string>
    <key>serviceInputTypeIdentifier</key><string>com.apple.Automator.fileSystemObject</string>
    <key>serviceOutputTypeIdentifier</key><string>com.apple.Automator.nothing</string>
    <key>serviceProcessesInput</key><integer>1</integer>
    <key>workflowTypeIdentifier</key><string>com.apple.Automator.servicesMenu</string>
  </dict>
</dict>
</plist>
PLIST

/usr/bin/plutil -lint "$SERVICE_DIR/Contents/Info.plist" >/dev/null
/usr/bin/plutil -lint "$SERVICE_DIR/Contents/document.wflow" >/dev/null
/System/Library/CoreServices/pbs -update >/dev/null 2>&1 || true
/System/Library/CoreServices/pbs -flush >/dev/null 2>&1 || true
/usr/bin/killall Finder >/dev/null 2>&1 || true

echo "Installed: Send to Gigapixel Queue"
echo "Right-click an image in Finder and choose Quick Actions → Send to Gigapixel Queue."
