#!/bin/zsh
set -euo pipefail

APP_DIR="$HOME/Library/Application Support/GigapixelSamurai"
CONFIG="$APP_DIR/config"
KEYCHAIN_SERVICE="GigapixelSamurai"
mkdir -p "$APP_DIR"

get_config() {
  [[ -f "$CONFIG" ]] || return 0
  /usr/bin/awk -F= -v key="$1" '$1 == key { sub(/^[^=]*=/, ""); print; exit }' "$CONFIG"
}

write_default_config() {
  cat > "$CONFIG" <<'EOF'
endpoint=https://gigapixel.novabyteworks.com
username=
project=Inbox
model=wonder
scale=4
strength=high
labels=
EOF
  chmod 600 "$CONFIG"
}

[[ -f "$CONFIG" ]] || write_default_config
ENDPOINT="$(get_config endpoint)"
USERNAME="$(get_config username)"
PROJECT="$(get_config project)"
MODEL="$(get_config model)"
SCALE="$(get_config scale)"
STRENGTH="$(get_config strength)"
LABELS="$(get_config labels)"

if [[ -z "$USERNAME" ]]; then
  USERNAME="$(/usr/bin/osascript -e 'text returned of (display dialog "Gigapixel Samurai username" default answer "")')"
  /usr/bin/sed -i '' "s/^username=.*/username=${USERNAME//\/\\}/" "$CONFIG"
fi

PASSWORD="$(/usr/bin/security find-generic-password -s "$KEYCHAIN_SERVICE" -a "$USERNAME" -w 2>/dev/null || true)"
if [[ -z "$PASSWORD" ]]; then
  PASSWORD="$(/usr/bin/osascript -e 'text returned of (display dialog "Gigapixel Samurai password" default answer "" with hidden answer)')"
  /usr/bin/security add-generic-password -U -s "$KEYCHAIN_SERVICE" -a "$USERNAME" -w "$PASSWORD" >/dev/null
fi

if [[ "$#" -eq 0 ]]; then
  /usr/bin/osascript -e 'display alert "Gigapixel Samurai" message "Select one or more image files in Finder, then use the Send to Gigapixel Queue Quick Action."'
  exit 1
fi

FORM=(
  -F "project=$PROJECT"
  -F "model=$MODEL"
  -F "scale=$SCALE"
  -F "strength=$STRENGTH"
  -F "labels=$LABELS"
)
for file in "$@"; do
  [[ -f "$file" ]] && FORM+=( -F "files=@${file}" )
done

RESPONSE="$(/usr/bin/curl --silent --show-error --fail-with-body --max-time 3600 \
  --user "$USERNAME:$PASSWORD" "${FORM[@]}" \
  "${ENDPOINT%/}/api/jobs")" || {
    /usr/bin/osascript -e 'display alert "Gigapixel queue failed" message "The selected file could not be queued. Check the queue address and sign-in settings."'
    exit 1
  }

/usr/bin/osascript -e "display notification \"Selected image(s) added to ${PROJECT}.\" with title \"Gigapixel Samurai\""
