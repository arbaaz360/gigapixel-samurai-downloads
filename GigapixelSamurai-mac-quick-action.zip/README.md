# macOS right-click queue

This installs a Finder Quick Action named **Send to Gigapixel Queue**. It accepts one or more selected local images and posts them directly to the Windows-hosted queue; Gigapixel Samurai does not need to be open on the Mac.

Copy this `macos` folder to the Mac and run:

```zsh
chmod +x install-quick-action.sh send_to_gigapixel.sh
./install-quick-action.sh
```

The installer refreshes Finder's Quick Actions list. If the action is still hidden, right-click an image, choose **Quick Actions → Customize…**, enable **Send to Gigapixel Queue**, and click **Done**.

The first use asks for the queue username and password. The password is stored in the macOS Keychain. Edit `~/Library/Application Support/GigapixelSamurai/config` to change the public address, project, labels, model, scale, or strength. The default is Wonder 4× High.

The default address is `https://gigapixel.novabyteworks.com`. If the service uses a different address, change `endpoint=` before the first use.
